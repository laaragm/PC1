
package Visao;

import java.io.File;

/**
 *
 * @author Gabriel Bernalle, Ana Carolina, Lara Galvani, Lorena Gomes
 */
public class Main {
    
    public static void main(String[] args) {
        
        TelaLogin tela = new TelaLogin();
        tela.setSize(600, 400);
        tela.setTitle("Condomínio");
        tela.setLocationRelativeTo(null);
        tela.setVisible(true);
        File file = new File("moradores.txt");
    }
}
