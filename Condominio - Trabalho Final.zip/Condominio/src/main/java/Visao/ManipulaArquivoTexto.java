package Visao;

import Controle.AspectosReserva;
import Controle.Conta;
import Controle.Moradores;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;
/**
 *
 * @author Gabriel Bernalle, Ana Carolina, Lara Galvani, Lorena Gomes
 */
public class ManipulaArquivoTexto {
    
    ArrayList Moradores = new ArrayList<>();
    
    public ManipulaArquivoTexto() {
    }
    
    public ManipulaArquivoTexto(String nomeArquivo){
                    
        try{
            File file = new File(nomeArquivo); 
            if(!file.exists()){ //se o arquivo não existir vai criar um novo
                file.createNewFile();
            }  
        }catch(IOException e){
            System.out.println("Erro: "+ e.getMessage());
        }   
    }    
       
    public boolean salvarContatoFileWriter(String nomeArquivo, Moradores c){
        
        //o true é que o conteúdo será acrescentado ao invés de ser substituído
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(nomeArquivo, true))){
            try (PrintWriter gravar = new PrintWriter(bw)) {
                gravar.println(c.toString()); //grava o contato no arquivo txt
            } //grava o contato no arquivo txt
            bw.close();
            return true;
        }catch(IOException e){ //tratamento de exceção (input/output)
            System.out.println("Erro: "+ e.getMessage());
            return false;
        }
    }
              
    public boolean lerContatoFileReader(String nomeArquivo, Moradores c){
               
        try(BufferedReader lerArquivo = new BufferedReader(new FileReader(nomeArquivo))){ 
            String linha = lerArquivo.readLine(); //lê a primeira linha
            //a variável "linha" recebe o valor "null" quando chegar no final do arquivo texto
            while(linha!=null){
                if(linha.equals(c.toString())){
                    return true;
                }
                linha = lerArquivo.readLine(); //lê da segunda até a última linha
            }   
            lerArquivo.close();
        }catch(IOException e){
            System.out.println("Erro: "+ e.getMessage());
        }
        return false;
    }
    
    public boolean lerContatoFileReader(String nomeArquivo, String c){
               
        try(BufferedReader lerArquivo = new BufferedReader(new FileReader(nomeArquivo))){ 
            String linha = lerArquivo.readLine(); //lê a primeira linha
            //a variável "linha" recebe o valor "null" quando chegar no final do arquivo texto
            while(linha!=null){
                if(linha.equals(c)){
                    return true;
                }
                linha = lerArquivo.readLine(); //lê da segunda até a última linha
            }   
            lerArquivo.close();
        }catch(IOException e){
            System.out.println("Erro: "+ e.getMessage());
        }
        return false;
    }        
        
    public boolean salvarConta(String nomeArquivo, Conta c){
        
        //o true é que o conteúdo será acrescentado ao invés de ser substituído
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(nomeArquivo, true))){
            try (PrintWriter gravar = new PrintWriter(bw)) {
                gravar.println(c.toString()); //grava o contato no arquivo txt
            } //grava o contato no arquivo txt
            bw.close();
            return true;
        }catch(IOException e){ //tratamento de exceção (input/output)
            System.out.println("Erro: "+ e.getMessage());
            return false;
        }
    }
    
    public boolean salvarReserva(String nomeArquivo, AspectosReserva r){
        
        //o true é que o conteúdo será acrescentado ao invés de ser substituído
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(nomeArquivo, true))){
            try (PrintWriter gravar = new PrintWriter(bw)) {
                gravar.println(r.toString()); //grava o contato no arquivo txt
            } //grava o contato no arquivo txt
            bw.close();
            return true;
        }catch(IOException e){ //tratamento de exceção (input/output)
            System.out.println("Erro: "+ e.getMessage());
            return false;
        }
    }
    
}
