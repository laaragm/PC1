package Controle;

import java.util.ArrayList;

/**
 *
 * @author Gabriel Bernalle, Ana Carolina, Lara Galvani, Lorena Gomes
 */
public class ControlePagamento {
    
    ArrayList<Conta> lista;

    public ControlePagamento(){
        lista = new ArrayList<>();
    }

    public ArrayList<Conta> getLista(){
        return (ArrayList<Conta>) lista;
    }
    
    public void adicionarConta(Conta conta){
        lista.add(conta);
    }
  
    public double somaDespesasMes(String mes){
        
        double soma = 0;
        if(mes.equals("janeiro") || mes.equals("Janeiro") || mes.equals("JANEIRO") || mes.equals("01") || mes.equals("1")){
            for(Conta contas : lista){
                if(contas.getVencimento().equals("Janeiro")){
                    soma = soma + Double.parseDouble(contas.getValor());
                }
            }
        }else if(mes.equals("fevereiro") || mes.equals("Fevereiro") || mes.equals("FEVEREIRO") || mes.equals("02") || mes.equals("2")){
            for(Conta contas : lista){
                if(contas.getVencimento().equals("Fevereiro")){
                    soma = soma + Double.parseDouble(contas.getValor());
                }
            }
        }
        return soma;
    }
    
    public void exibirDespesas(){
        for(Conta contas: lista){
            System.out.println(contas.toString());  
            System.out.println("");
        }
    }
}
