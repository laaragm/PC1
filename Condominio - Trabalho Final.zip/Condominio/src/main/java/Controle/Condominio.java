package Controle;

/**
 *
 * @author Gabriel Bernalle, Ana Carolina, Lara Galvani, Lorena Gomes
 */
public class Condominio {
    
    private Apartamento apartamentos[];
    private int qt_aptos = 9;
    
    public Condominio(){ //método construtor sem parâmetro
        
        apartamentos = new Apartamento[qt_aptos];
    }

    @Override
    public String toString() {
        return "Condominio " + "apartamentos:" + apartamentos + ", qt_aptos:" + qt_aptos;
    }
      
    public boolean apartamentoOcupado(int pos){
        
        boolean haMorador = false;
        //procura pela posição do apartamento, se no nome tiver algo então o apto está ocupado
        if(!apartamentos[pos].getMoradores().get(pos).getNome().equals(null)){
            haMorador = true;
            return haMorador;
        }
        return haMorador;
    }
 
}
