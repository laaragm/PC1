package Controle;

/**
 *
 * @author Gabriel Bernalle, Ana Carolina, Lara Galvani, Lorena Gomes
 */
public class Conta {
    
    protected String nome;
    protected String vencimento;
    protected String valor;

    public Conta(String nome, String vencimento, String valor) {
        this.nome = nome;
        this.vencimento = vencimento;
        this.valor = valor;
    }
   
    public Conta(){
     //super() só onde tem extends, onde tem implements não
    }

    @Override
    public String toString() {
        return nome + "," + vencimento + "," + valor;
    }
    
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getVencimento() {
        return vencimento;
    }

    public void setVencimento(String vencimento) {
        this.vencimento = vencimento;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
    
}
