package Controle;

import javax.swing.JOptionPane;

/**
 *
 * @author Gabriel Bernalle, Ana Carolina, Lara Galvani, Lorena Gomes
 */
public class NaoExisteMoradorException extends Exception {
    
    public NaoExisteMoradorException(){
        super("O morador não consta no sistema. Tente novamente.");
        //JOptionPane.showMessageDialog(null, "O morador não consta no sistema. Tente novamente.", JOptionPane.ERROR_MESSAGE);
        
    }
}
