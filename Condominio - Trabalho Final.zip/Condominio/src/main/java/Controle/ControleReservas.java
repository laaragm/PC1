package Controle;

import java.util.ArrayList;

/**
 *
 * @author Gabriel Bernalle, Ana Carolina, Lara Galvani, Lorena Gomes
 */
public class ControleReservas {
    
    ArrayList<AspectosReserva> lista = new ArrayList<>();

    public ControleReservas() {
    }

    public ArrayList<AspectosReserva> getLista() {
        return lista;
    }

    public void setLista(ArrayList<AspectosReserva> lista) {
        this.lista = lista;
    }

    @Override
    public String toString() {
        return "ControleReservas{" + "lista=" + lista + '}';
    }
    
    public void adicionarReserva(AspectosReserva reserva){
        
        lista.add(reserva);
    }
}
