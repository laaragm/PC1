package Controle;

import Visao.Busca;
import Visao.ManipulaArquivoTexto;
import Visao.Reservas;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Integer.parseInt;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Gabriel Bernalle, Ana Carolina, Lara Galvani, Lorena Gomes
 */
public class BuscaControle {
    
    private static Busca busca = new Busca();

    public static void buscaAbrir() {

        busca.setVisible(true);
        busca.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    public static void buscarMorador(String nome) {
        ArrayList<Moradores> m = new ArrayList<>();
        Moradores moradorEncontrado = null;
        
        try {
            Scanner leitor = new Scanner(new File("moradores.txt"));
            while (leitor.hasNext()) { 
                String linha = leitor.nextLine();
                //a cada vírgula encontrada vai salvar a palavra em um vetor "aux" até a próxima vírgula
                String[] aux = linha.split(","); 
                //salva cada atributo em uma posição do vetor
                String nome1 = aux[0];
                String dataNasc1 = aux[1];
                String cpf1 = aux[2];
                String identidade1 = aux[3];
                String telefone1 = aux[4];
                String email1 = aux[5];
                String apartamento1 = aux[6];
                //cria um novo morador com os atributor encontrados no arquivo
                Moradores morador = new Moradores(nome1, dataNasc1, cpf1, identidade1, telefone1, email1, apartamento1);
                //adiciona o morador ao ArrayList
                m.add(morador);  
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        for(int i = 0; i < m.size(); i++){
            if(m.get(i).getNome().equals(nome))
                moradorEncontrado = m.get(i);
        }
        
        if(moradorEncontrado != null){ //se encontrou o morador
            JOptionPane.showMessageDialog(null, String.format("Nome: %s\nData Nasc.: %s\nCPF: %s\nIdentidade: %s\nTelefone: %s\nEmail: %s\nApartamento: %s\n", moradorEncontrado.getNome(),moradorEncontrado.getDataNasc(), moradorEncontrado.getCpf(), moradorEncontrado.getIdentidade(), moradorEncontrado.getTelefone(), moradorEncontrado.getEmail(), moradorEncontrado.getApartamento()),"Resultado da busca",JOptionPane.INFORMATION_MESSAGE);
        }else{
            JOptionPane.showMessageDialog(null, "Morador não encontrado. Tente novamente.");
        }
    }
    
    public void listarMoradores(){
        
        //percorre o arquivo, adiciona cada morador ao ArrayList e percorre o ArrayList exibindo as informações de cada morador
        ArrayList<Moradores> m = new ArrayList<>();
        boolean haMorador = false; //para exibir algo caso não tenha morador
        
        try {
            Scanner leitor = new Scanner(new File("moradores.txt"));
            while (leitor.hasNext()) { 
                String linha = leitor.nextLine();
                //a cada vírgula encontrada vai salvar a palavra em um vetor "aux" até a próxima vírgula
                String[] aux = linha.split(","); 
                //salva cada atributo em uma posição do vetor
                String nome1 = aux[0];
                String dataNasc1 = aux[1];
                String cpf1 = aux[2];
                String identidade1 = aux[3];
                String telefone1 = aux[4];
                String email1 = aux[5];
                String apartamento1 = aux[6];
                //cria um novo morador com os atributor encontrados no arquivo
                Moradores morador = new Moradores(nome1, dataNasc1, cpf1, identidade1, telefone1, email1, apartamento1);
                //adiciona o morador ao ArrayList
                m.add(morador);  
                if(nome1 != null){
                    haMorador = true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        if(haMorador){ 
            for(Moradores morad: m){ //for each-> tipo apelido: coleção
                JOptionPane.showMessageDialog(null, String.format("Nome: %s\nData Nasc.: %s\nCPF: %s\nIdentidade: %s\nTelefone: %s\nEmail: %s\nApartamento: %s\n", morad.getNome(),morad.getDataNasc(), morad.getCpf(), morad.getIdentidade(), morad.getTelefone(), morad.getEmail(), morad.getApartamento()),"Resultado da busca",JOptionPane.INFORMATION_MESSAGE);
            }
        }else{ 
            JOptionPane.showMessageDialog(null, "Não existem moradores cadastrados. Tente novamente.");
        }
        
        
    }
    
    public boolean listarMoradorPorAp(String numeroAp){
        
        //percorre o arquivo, adiciona cada morador ao ArrayList e percorre o ArrayList exibindo as informações de cada morador
        ArrayList<Moradores> m = new ArrayList<>();
        boolean haMorador = false; //para exibir algo caso não tenha morador
        
        try {
            Scanner leitor = new Scanner(new File("moradores.txt"));
            while (leitor.hasNext()) { 
                String linha = leitor.nextLine();
                //a cada vírgula encontrada vai salvar a palavra em um vetor "aux" até a próxima vírgula
                String[] aux = linha.split(","); 
                //salva cada atributo em uma posição do vetor
                String nome1 = aux[0];
                String dataNasc1 = aux[1];
                String cpf1 = aux[2];
                String identidade1 = aux[3];
                String telefone1 = aux[4];
                String email1 = aux[5];
                String apartamento1 = aux[6];
                //só vai adicionar o morador se o número do ap lido no arquivo for igual ao número procurado
                if(apartamento1.equals(numeroAp)){
                    Moradores morador = new Moradores(nome1, dataNasc1, cpf1, identidade1, telefone1, email1, apartamento1);
                    m.add(morador); 
                    haMorador = true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        if(haMorador){ 
            for(Moradores morad: m){ //for each-> tipo apelido: coleção
                JOptionPane.showMessageDialog(null, String.format("Nome: %s\nData Nasc.: %s\nCPF: %s\nIdentidade: %s\nTelefone: %s\nEmail: %s\nApartamento: %s\n", morad.getNome(),morad.getDataNasc(), morad.getCpf(), morad.getIdentidade(), morad.getTelefone(), morad.getEmail(), morad.getApartamento()),"Resultado da busca",JOptionPane.INFORMATION_MESSAGE);
                return true;
            }
        }else{ 
            JOptionPane.showMessageDialog(null, "Não existe morador cadastrado. Tente novamente.");
        }
        
        return false;
    }
        
    public boolean excluiMorador(String file, String parametro) throws IOException{ //parametro é o numero do ap
        
        try{
            File inFile = new File(file);
            //Cria um novo arquivo que mais tarde terá o nome do arquivo original passado por parametro
            File tempFile = new File(inFile.getAbsolutePath() + ".tmp"); //arquivo temporário
            BufferedReader br = new BufferedReader(new FileReader(file));
            PrintWriter pw = new PrintWriter(new FileWriter(tempFile));
            
            String linha = null;

            //Lê o arquivo original e escreve no novo a menos que seja encontrado o conteúdo a ser removido
            while ((linha = br.readLine()) != null) { //lê enquanto não chegar no fim do arquivo
                //trim() remove o espaço em branco no ínicio e no final de uma string
                if (!linha.trim().contains(parametro)) { //se a linha não contem o numero do ap que queremos excluir
                pw.println(linha); //copia a linha para o arquivo
                //flush é para obrigar realmente a escrever os dados
                //write apenas os escreve em um buffer que depois, de fato, escreve no txt (nesse caso)
                pw.flush(); 
              }
            }
             pw.close(); 
             br.close();

            inFile.delete(); //Deleta o arquivo original
            //Renomeia o arquivo novo (ficará com o mesmo nome do arquivo antigo - passado por parâmetro) 
            tempFile.renameTo(inFile);
            
            return true; //deu tudo certo

        }catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }catch (IOException e) {
            e.printStackTrace();
            return false;
        }               
        
    }
    
    public static boolean verificarStatusAp(String numeroAp) {
        
        ArrayList<Moradores> m = new ArrayList<>();
        boolean haMorador = false;
        
        try {
            Scanner leitor = new Scanner(new File("moradores.txt"));
            while (leitor.hasNext()) { 
                String linha = leitor.nextLine();
                //a cada vírgula encontrada vai salvar a palavra em um vetor "aux" até a próxima vírgula
                String[] aux = linha.split(","); 
                //salva cada atributo em uma posição do vetor
                String nome1 = aux[0];
                String dataNasc1 = aux[1];
                String cpf1 = aux[2];
                String identidade1 = aux[3];
                String telefone1 = aux[4];
                String email1 = aux[5];
                String apartamento1 = aux[6];
                //cria um novo morador com os atributor encontrados no arquivo
                Moradores morador = new Moradores(nome1, dataNasc1, cpf1, identidade1, telefone1, email1, apartamento1);
                //adiciona o morador ao ArrayList
                m.add(morador);  
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        //percorre o ArrayList para verificar se o apartamento está vago
        for(int i = 0; i < m.size(); i++){
            if(m.get(i).getApartamento().equals(numeroAp)){
                haMorador = true;
            }
        }
        
        return haMorador;
    }
    
    public static void aptosOcupados() {
        
        ArrayList<Moradores> m = new ArrayList<>();
                
        try {
            Scanner leitor = new Scanner(new File("moradores.txt"));
            while (leitor.hasNext()) { 
                String linha = leitor.nextLine();
                //a cada vírgula encontrada vai salvar a palavra em um vetor "aux" até a próxima vírgula
                String[] aux = linha.split(","); 
                //salva cada atributo em uma posição do vetor
                String nome1 = aux[0];
                String dataNasc1 = aux[1];
                String cpf1 = aux[2];
                String identidade1 = aux[3];
                String telefone1 = aux[4];
                String email1 = aux[5];
                String apartamento1 = aux[6];
                //cria um novo morador com os atributor encontrados no arquivo
                Moradores morador = new Moradores(nome1, dataNasc1, cpf1, identidade1, telefone1, email1, apartamento1);
                //adiciona o morador ao ArrayList
                m.add(morador);  
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        int numAp = 100;  
        boolean nenhumOcupado = true;
        int aux = 0;
        while(numAp != 900){
            for(int i = 0; i < m.size(); i++){ //ArrayList de moradores
                int comparacao = parseInt(m.get(i).getApartamento());
                if(comparacao == numAp){
                    JOptionPane.showMessageDialog(null, String.format("O apartamento %d está ocupado.", numAp));
                    nenhumOcupado = false;
                }
            }
            numAp = numAp + 100;
        }
        if(nenhumOcupado){
            JOptionPane.showMessageDialog(null, "Todos os apartamentos estão disponíveis.");
        }
    }
    
    public static int qtAptosOcupados() {
        
        ArrayList<Moradores> m = new ArrayList<>();
                
        try {
            Scanner leitor = new Scanner(new File("moradores.txt"));
            while (leitor.hasNext()) { 
                String linha = leitor.nextLine();
                //a cada vírgula encontrada vai salvar a palavra em um vetor "aux" até a próxima vírgula
                String[] aux = linha.split(","); 
                //salva cada atributo em uma posição do vetor
                String nome1 = aux[0];
                String dataNasc1 = aux[1];
                String cpf1 = aux[2];
                String identidade1 = aux[3];
                String telefone1 = aux[4];
                String email1 = aux[5];
                String apartamento1 = aux[6];
                //cria um novo morador com os atributor encontrados no arquivo
                Moradores morador = new Moradores(nome1, dataNasc1, cpf1, identidade1, telefone1, email1, apartamento1);
                //adiciona o morador ao ArrayList
                m.add(morador);  
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        int numAp = 100;  
        int qtOcupados = 0;
        int aux = 0;
        while(numAp != 900){
            for(int i = 0; i < m.size(); i++){ //ArrayList de moradores
                int comparacao = parseInt(m.get(i).getApartamento());
                if(comparacao == numAp){
                    qtOcupados++;
                }
            }
            numAp = numAp + 100;
        }
        return qtOcupados;
    }
        
    public boolean verificacaoContas(String mes){

        ArrayList<Conta> c = new ArrayList<>();
        boolean haConta = false;
        double soma = 0;
        double valorCondominio = 7000;

        try {
            Scanner leitor = new Scanner(new File("contas.txt"));
            while (leitor.hasNext()) { 
                String linha = leitor.nextLine();
                String[] aux = linha.split(","); 
                String nome1 = aux[0];
                String mes1 = aux[1];
                String valor1 = aux[2];

                if(mes1.equals(mes)){
                    Conta conta = new Conta(nome1, mes1, valor1);
                    c.add(conta); 
                    haConta = true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(haConta){ 
            for(Conta conta: c){ //for each-> tipo apelido: coleção
                if(conta.getVencimento().equals(mes)){
                    soma = soma + Double.parseDouble(conta.getValor());
                }
            }
            double total = valorCondominio - soma;
            JOptionPane.showMessageDialog(null, String.format("Resultado do mês de %s: R$%.2f", mes, total));
        }else{ 
            JOptionPane.showMessageDialog(null, "As contas desse mês não foram cadastradas. Tente novamente.");
        }

        return haConta;
    }
    
    public static boolean verificarSePodeReservar(String data) {
        
        ArrayList<AspectosReserva> r = new ArrayList<>();
        boolean podeReservar = true;
        
        try {
            Scanner leitor = new Scanner(new File("reservas.txt"));
            while (leitor.hasNext()) { 
                String linha = leitor.nextLine();
                String[] aux = linha.split(","); 
                String nome1 = aux[0];
                String data1 = aux[1];
                AspectosReserva reserva = new AspectosReserva(nome1, data1);
                r.add(reserva);  
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        for(int i = 0; i < r.size(); i++){
            if(r.get(i).getData().equals(data)){
                JOptionPane.showMessageDialog(null, "A data escolhida já foi reservada.");
                podeReservar = false;
            } 
        }
        return podeReservar;
    }
    
    public boolean listarReservas(){
        
        ArrayList<AspectosReserva> m = new ArrayList<>();
        //ControleReservas controle = new ControleReservas();
        boolean haReserva = false; 
        int i = 0;
        
        try {
            Scanner leitor = new Scanner(new File("reservas.txt"));
            while (leitor.hasNext()) { 
                String linha = leitor.nextLine();
                String[] aux = linha.split(","); 
                String nome1 = aux[0];
                String data1 = aux[1];
                
                AspectosReserva reserva = new AspectosReserva(nome1, data1);
                m.add(reserva);
                
                if(nome1 != null){
                    haReserva = true;
                }
                if(haReserva){
                    JOptionPane.showMessageDialog(null, String.format("Nome: %s\nData da Reserva.: %s\n", m.get(i).getNome(), m.get(i).getData()),"Resultado da busca",JOptionPane.INFORMATION_MESSAGE);
                    i++;
                }
                //System.out.println(m.toString());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        if(!haReserva){  
            JOptionPane.showMessageDialog(null, "Nenhuma reserva foi cadastrada.");
        }
        
        return false;
    }
    
}
