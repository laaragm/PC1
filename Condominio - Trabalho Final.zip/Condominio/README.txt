Favor não mexer no conteúdo do arquivo texto. Entretanto, você pode apagá-lo para que o condomínio não tenha nenhum morador cadastrado.
Caso o compilador pergunte, a classe principal é a Main que está no pacote Visao.

Login: Luciana	
Senha: 1234

Fizemos um vídeo mostrando o projeto (caso o SO mostre as imagens/textos não proporcionais ou algo do tipo) -  https://youtu.be/bHmyExF876k

Grupo: Lara, Gabriel Bernalle, Lorena, Carol

