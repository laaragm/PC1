/**
 *
 * @author Lara
 */
//Funcionários que trabalham por hora (terceirizados) – são pagos por hora trabalhada;
public class Terceirizado extends Empregado{

    public Terceirizado(String nome, String sobrenome, int numIdentidade) {
        super(nome, sobrenome, numIdentidade);
    }

    public Terceirizado() {
    }
        
    @Override
    public double getValorAPagar(double horasTrabalhadas){
        double valor = horasTrabalhadas * ControlePagamento.HORA;        
        return valor;   
    }
}
