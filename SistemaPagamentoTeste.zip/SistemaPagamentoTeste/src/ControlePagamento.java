import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/**
 *
 * @author Lara
 */
public class ControlePagamento{

    public static final double HORA = 8.00; 
    public static final double SALARIO = 954.00;
    private List<Pagavel> lista;

    public ControlePagamento(){
        lista = new ArrayList<>();
    }

    public ArrayList<Pagavel> getLista(){
        return (ArrayList<Pagavel>) lista;
    }

    @Override
    public String toString(){
        return "ControlePagamento{" + "lista=" + lista + '}';
    }

    public void setLista(ArrayList<Pagavel> lista) {
        this.lista = lista;
    }
            
    public void adicionarConta(Pagavel conta){
        lista.add(conta);
        System.out.println("Conta adicionada com sucesso");
    }
    
    public void adicionarTrabalhador(Pagavel trabalhador){
        lista.add(trabalhador);
        System.out.println("Trabalhador adicionado com sucesso");
    }
    
    public void exibirDespesas(){
        for(Pagavel pagaveis: lista){
            System.out.println(pagaveis.toString());  
            System.out.println("");
        }
    }
   
}
