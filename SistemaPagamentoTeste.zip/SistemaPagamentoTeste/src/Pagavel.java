import java.util.ArrayList;
/**
 *
 * @author Lara
 */
public interface Pagavel{
    
    public abstract double getValorAPagar(double extras);  
}
