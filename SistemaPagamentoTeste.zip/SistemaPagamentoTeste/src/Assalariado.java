/**
 *
 * @author Lara
 */
/*Funcionários assalariados – que recebem salários fixos quando não ultrapassam 40
horas por semana. Quando isso ocorre, recebem o salário, mais as horas-extras trabalhadas*/
public class Assalariado extends Empregado{
       
    public Assalariado(String nome, String sobrenome, int numIdentidade){
        super(nome, sobrenome, numIdentidade);
    }

    public Assalariado(){
    }
      
    @Override
    public double getValorAPagar(double horasExtras){
       double valor = ControlePagamento.SALARIO + (horasExtras * ControlePagamento.HORA);
       return valor;
    }
    
}
