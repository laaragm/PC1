/**
 *
 * @author Lara
 */
/*Contas de concessionárias (contas de água, luz, gás, telefone) – cujo valor de pagamento
não sofre alterações, ainda que realizado após o vencimento.*/
public class Concessionaria extends Conta{

    public Concessionaria(int dia, int mes, double valor){
        super(dia, mes, valor);
    }

    public Concessionaria(){
    } 
    
    @Override
    public double getValorAPagar(double extras){
        extras = 0; //só pra passar algum parâmetro mesmo pra poder sobrescrever o método de Pagavel
        return valor;
    }
}
