/**
 *
 * @author Lara
 */
/*Funcionários assalariados/comissionados – recebem um salário-base mais uma
porcentagem sobre suas vendas – 6%.*/
public class AssalariadoComissionado extends Comissionado{

    public AssalariadoComissionado(String nome, String sobrenome, int numIdentidade) {
        super(nome, sobrenome, numIdentidade);
    }

    public AssalariadoComissionado() {
    }
     
    @Override
    public double getValorAPagar(double valorVendas){
        double valor = ControlePagamento.SALARIO + (0.06 * valorVendas);
        return valor;
             
    }
}
