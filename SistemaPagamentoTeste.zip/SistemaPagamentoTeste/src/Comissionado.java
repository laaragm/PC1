/**
 *
 * @author Lara
 */
//Funcionários comissionados – recebem 6% sobre suas vendas;
public class Comissionado extends Empregado{

    public Comissionado(String nome, String sobrenome, int numIdentidade) {
        super(nome, sobrenome, numIdentidade);
    }

    public Comissionado() {
    }
    
    @Override
    public double getValorAPagar(double valorVendas){
        double valor = valorVendas * 0.06;
        return valor;
    }
}
