import java.util.Scanner;
/**
 *
 * @author Lara
 */
/*A empresa quer implantar um aplicativo de contabilidade em Java que realiza os cálculos de
contas a pagar polimorfcamente e que eiiba uma relação dos valores a serem pagos por
funcionário e por conta e um resumo com o total de valores a serem pagos no mês.*/
public class SistemaPagamentoTeste{
    
    public static void main(String[] args){
     
        ControlePagamento lista = new ControlePagamento();
        
        Scanner input = new Scanner(System.in);
        
        int diaConta, mesConta, diasAtraso, numId, op=0, tipo;
        double valor, horasExtras, vendas, horasTrabalhadas, totalDespesas=0;
        String nome, sobrenome;
        
        System.out.println("Seja bem vindo(a) ao controle de pagamentos da sua empresa");
        while(op!=4){
            System.out.println("Selecione a opção desejada: ");
            System.out.println("1- Inserir Conta");
            System.out.println("2- Inserir Funcionario");
            System.out.println("3- Exibir as despesas totais da empresa");
            System.out.println("4- Sair");
            op = input.nextInt();
            
            switch(op){
                case 1: //Inserir Conta
                    System.out.println("Digite a opção desejada: ");
                    System.out.println("1- Inserir título a pagar (cujo valor será acrescido de 10% de multa quando pagas após o vencimento)");
                    System.out.println("2- Inserir conta de concessionária(contas de água, luz, gás, telefone)");
                    tipo = input.nextInt();
                    if(tipo == 1){
                        System.out.println("Entre com o dia da conta: ");
                        diaConta = input.nextInt();
                        System.out.println("Entre com o mês da conta: ");
                        mesConta = input.nextInt();
                        System.out.println("Entre com o valor da conta: ");
                        valor = input.nextDouble();
                        System.out.println("Entre com o número de dias que a conta foi paga com atraso: ");
                        diasAtraso = input.nextInt();
                        Pagavel p = new Titulo(diaConta, mesConta, valor);
                        lista.adicionarConta(p);
                        totalDespesas = totalDespesas + p.getValorAPagar(diasAtraso);
                    }else{
                        System.out.println("Entre com o dia da conta: ");
                        diaConta = input.nextInt();
                        System.out.println("Entre com o mês da conta: ");
                        mesConta = input.nextInt();
                        System.out.println("Entre com o valor da conta: ");
                        valor = input.nextDouble();
                        Pagavel p = new Concessionaria(diaConta, mesConta, valor);
                        lista.adicionarConta(p);
                        totalDespesas = totalDespesas + p.getValorAPagar(0); //pois não tem atraso
                    }
                   break;
                
                case 2: //Inserir Funcionario
                    
                        System.out.println("Digite a opção desejada: ");
                        System.out.println("1- Inserir funcionário assalariado");
                        System.out.println("2- Inserir funcionário comissionado");
                        System.out.println("3- Inserir funcionário terceirizado");
                        System.out.println("4- Inserir funcionário assalariado comissionado");
                        tipo = input.nextInt();
                    
                    
                    switch (tipo) {
                        case 1: //assalariado
                            System.out.println("Entre com o primeiro nome do funcionário:");
                            nome = input.next();
                            System.out.println("Entre com o último nome do funcionário:");
                            sobrenome = input.next();
                            System.out.println("Entre com o número de identidade do funcionário:");
                            numId = input.nextInt();
                            System.out.println("Entre com a quantidade de horas extras (caso o funcionário tenha trabalhado mais de 40 horas por semana): ");
                            horasExtras = input.nextDouble();
                            Pagavel p = new Assalariado(nome, sobrenome, numId);
                            lista.adicionarTrabalhador(p);
                            totalDespesas = totalDespesas + p.getValorAPagar(horasExtras);
                            break;
                    
                        case 2: //comissionado
                            System.out.println("Entre com o primeiro nome do funcionário:");
                            nome = input.next();
                            System.out.println("Entre com o último nome do funcionário:");
                            sobrenome = input.next();
                            System.out.println("Entre com o número de identidade do funcionário:");
                            numId = input.nextInt();
                            System.out.println("Entre com o valor total de vendas desse funcionário no mês:");
                            vendas = input.nextDouble();
                            Pagavel p2 = new Comissionado(nome, sobrenome, numId);
                            lista.adicionarTrabalhador(p2);
                            totalDespesas = totalDespesas + p2.getValorAPagar(vendas);
                            break;
                    
                        case 3: //terceirizado
                            System.out.println("Entre com o primeiro nome do funcionário:");
                            nome = input.next();
                            System.out.println("Entre com o último nome do funcionário:");
                            sobrenome = input.next();
                            System.out.println("Entre com o número de identidade do funcionário:");
                            numId = input.nextInt();
                            System.out.println("Entre com a quantidade de horas trabalhadas: ");
                            horasTrabalhadas = input.nextDouble();
                            Pagavel p3 = new Terceirizado(nome, sobrenome, numId);
                            lista.adicionarTrabalhador(p3);
                            totalDespesas = totalDespesas + p3.getValorAPagar(horasTrabalhadas);
                            break;
                            
                        case 4: //assalariado comissionado
                            System.out.println("Entre com o primeiro nome do funcionário:");
                            nome = input.next();
                            System.out.println("Entre com o último nome do funcionário:");
                            sobrenome = input.next();
                            System.out.println("Entre com o número de identidade do funcionário:");
                            numId = input.nextInt();
                            System.out.println("Entre com o valor total de vendas desse funcionário no mês:");
                            vendas = input.nextDouble();
                            Pagavel p4 = new AssalariadoComissionado(nome, sobrenome, numId);
                            lista.adicionarTrabalhador(p4);
                            totalDespesas = totalDespesas + p4.getValorAPagar(vendas);
                        default:
                            break;
                    }
                    
                case 3: //Exibir despesas da empresa
                    System.out.printf("\nTotal de despesas do mês: R$%.2f\n\n", totalDespesas);
                    lista.exibirDespesas();
                    System.out.println("");
                    break;
                    
                default:
                    break;
                    
            }
        }
        
        
        
    }
}