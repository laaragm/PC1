/**
 *
 * @author Lara
 */
//Títulos – cujo valor será acrescido de 10% de multa quando pagas após o vencimento
public class Titulo extends Conta{

    public Titulo(int dia, int mes, double valor){
        super(dia, mes, valor);
    }

    public Titulo(){
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public double getValor() {
        return valor;
    }
       
    @Override //sobrescreve o método getValorAPagar que está na classe Pagavel
    public double getValorAPagar(double diasAposPgto){
        if(diasAposPgto > 0){ //se o usuário pagou a conta x dias depois do vencimento
            valor = valor + (valor * 0.1); //juros de 10%
            return valor;
        }else{
            return valor;
        }
    }
    
}
